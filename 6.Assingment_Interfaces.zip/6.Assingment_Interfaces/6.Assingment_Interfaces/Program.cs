﻿using System.Diagnostics;
using System.Xml.Linq;

namespace Assignment6Interfaces
{
    public interface GovtRules
    {
        public double EmpPF(double basicSalary);
        public string LeaveDetails();
        public double gratuityAmount(float servicecomp, double basicSalary);
    }
    public class Tcs : GovtRules
    {
        int empid;
        string name;
        string dept;
        string desig;
        double basicSalary;
        public Tcs(int empid, string name, string dept, string desig, double basicSalary)
        {
            this.empid = empid;
            this.name = name;
            this.dept = dept;
            this.desig = desig;
            this.basicSalary = basicSalary;
        }
        public void display()
        {
            Console.WriteLine($"empid:{empid} name:{name} dept:{dept} desig:{desig} basicSalary:{basicSalary}");
        }
        public double EmpPF(double basicSalary)
        {
            Console.WriteLine("TCS Salary Details:");
            double pf = (12.0 / 100) * basicSalary;
            Console.WriteLine("PF:" + pf);
            double empco = (8.33 / 100) * basicSalary;
            Console.WriteLine("Employee Contribution" + empco);
            double Pension = (3.67 / 100) * empco;
            Console.WriteLine("Pension:" + Pension);
            return basicSalary;
        }
        public string LeaveDetails()
        {
            Console.WriteLine("TCS leave Details");
            Console.WriteLine("1 day of casual leave per month");
            Console.WriteLine("12 days of sick leave per year");
            Console.WriteLine("10 days of Previlage leave per year");
            string m = "These are the leave details.";
            return m;
        }
        public double gratuityAmount(float servicecomp, double basicSalary)
        {
            if (servicecomp > 5 && servicecomp < 10)
            {
                double gratuityamount = basicSalary;
                Console.WriteLine("gratuity amount is:" + gratuityamount);
            }
            else if (servicecomp > 10 && servicecomp < 20)
            {
                double gratuityamount = basicSalary * 2;
                Console.WriteLine("gratuity amount is:" + gratuityamount);
            }
            else if (servicecomp > 20)
            {
                double gratuityamount = basicSalary * 3;
                Console.WriteLine("gratuity amount is:" + gratuityamount);
            }
            else if (servicecomp < 5)
            {
                Console.WriteLine("No Gratuity");
            }
            return basicSalary;
        }
    }
    public class Accenture : GovtRules
    {
        int empid;
        string name;
        string dept;
        string desig;
        double basicSalary;
        public Accenture(int empid, string name, string dept, string desig, double basicSalary)
        {
            this.empid = empid;
            this.name = name;
            this.dept = dept;
            this.desig = desig;
            this.basicSalary = basicSalary;
        }
        public void display()
        {
            Console.WriteLine($"empid:{empid} name:{name} dept:{dept} desig:{desig} basicSalary:{basicSalary}");
        }
        public double EmpPF(double basicSalary)
        {
            Console.WriteLine("Accenture Salary Details:");
            double pf = (12.0 / 100) * basicSalary;
            Console.WriteLine("PF:" + pf);
            double empco = (12.0 / 100) * basicSalary;
            Console.WriteLine("Employee Contribution" + empco);
            return basicSalary;
        }
        public string LeaveDetails()
        {
            Console.WriteLine("Accenture Leave Details");
            Console.WriteLine("2 day of casual leave per month");
            Console.WriteLine("5 days of sick leave per year");
            Console.WriteLine("5 days of Previlage leave per year");
            string n = "These are the Leave Details.";
            return n;
        }
        public double gratuityAmount(float servicecomp, double basicSalary)
        {
            Console.WriteLine("Gratutity amount : Not Applicable");
            double b = 10000;
            return b;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Tcs ob = new Tcs(int.Parse(Console.ReadLine()), Console.ReadLine(), Console.ReadLine(), Console.ReadLine(), double.Parse(Console.ReadLine()));
            ob.display();
            Console.WriteLine(ob.EmpPF(double.Parse(Console.ReadLine())));
            ob.LeaveDetails();
            Console.WriteLine(ob.gratuityAmount(float.Parse(Console.ReadLine()), double.Parse(Console.ReadLine())));
            Accenture a = new Accenture(int.Parse(Console.ReadLine()), Console.ReadLine(), Console.ReadLine(), Console.ReadLine(), double.Parse(Console.ReadLine()));
            a.display();
            Console.WriteLine(a.EmpPF(double.Parse(Console.ReadLine())));
            a.LeaveDetails();
            Console.WriteLine(a.gratuityAmount(float.Parse(Console.ReadLine()), double.Parse(Console.ReadLine())));
        }
    }
}