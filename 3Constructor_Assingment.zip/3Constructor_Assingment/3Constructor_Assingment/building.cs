﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3Constructor_Assingment
{
    class building
    {
        string type;
        string capacity;
        string dimension;
        int floorno;
        string docom;
        building()
        {
            type = Console.ReadLine();
            capacity = "2bhk";
            floorno = 1;
            docom = "21Dec2001";
            dimension = "20x30";
            docom = "23Apr2022";

        }
        void showdata()
        {
            if (type == "Flat")
            {
                Console.WriteLine($"type:{type} capacity:{capacity} floorno:{floorno} docom:{docom}");
            }
            else
            {
                Console.WriteLine($"type:{type} dimension:{dimension} docom:{docom}");
            }
        }
        static void Main()
        {
            building ob = new building();
            ob.showdata();

        }
    }
}
