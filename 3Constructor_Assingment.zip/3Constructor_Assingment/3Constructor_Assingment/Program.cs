﻿using System;

namespace _3Constructor_Assingment
{
    class Program
    {
        string fname;
        string Iname;
        string email;
        int dob;
        Program(string fname,string Iname,string email)
        {
            this.fname = fname;
            this.Iname = Iname;
            this.email = email;
        }
        Program(string fname,string Iname,int dob)
        {
            this.fname = fname;
            this.Iname = Iname;
            this.dob = dob;
        }
        void display()
        {
            Console.WriteLine($"fname:{fname}Iname:{Iname}email:{email}");
        }
        void dis()
        {
            Console.WriteLine($"fname:{fname}Iname:{Iname}:dob:{dob}");

        }

        static void Main(string[] args)
        {
            Program ob = new Program("Suchi", "kollipara", "kolliparasuchitha7372@gmail.com");
            Program ob1 = new Program(ob.fname, ob.fname, 21122001);
            ob.display();
            ob1.dis();

        }
    }
}
