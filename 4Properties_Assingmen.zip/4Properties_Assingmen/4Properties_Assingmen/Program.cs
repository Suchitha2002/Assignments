﻿namespace Assignment4properties
{
    internal class Bookstore
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string title { get; set; }
        public string author { get; set; }

        public const int quaofbooks = 3;
        public int price { get; set; }

        int total = 0;
        public void display()
        {
            for (int i = 1; i <= quaofbooks; i++)
            {
                Id = int.Parse(Console.ReadLine());
                Name = Console.ReadLine();
                title = Console.ReadLine();
                author = Console.ReadLine();
                price = int.Parse(Console.ReadLine());
                Console.WriteLine($"isdn:{Id} bookname:{Name} booktitle:{title} quantity:{quaofbooks} bookprice:{price}");
                total = total + price;
            }
        }

        void Billamount()
        {
            Console.WriteLine("The Total Billamount = " + total);
        }
        static void Main()
        {
            Bookstore ob = new Bookstore();
            ob.display();
            ob.Billamount();
        }
    }
}