using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static HandsOnModels.Pages.BookModel;
using static HandsOnModels.Pages.productModel;

namespace HandsOnModels.Pages
{
    public class BookAllPagesModel : PageModel
    {
		static List<Book> Books = new List<Book>()
		{
			new Book(){BookId=1,Name="Harry Potter",Price=200,Language="English",Author="J. K. Rowling"},
			 new Book(){BookId=2,Name="Then There Were None",Price=300,Language="English",Author="Agatha Christie"},
			  new Book(){BookId=3,Name="The Hobbit",Price=400,Language="English",Author="J. R. R. Tolkien"},

		};

		[BindProperty]
		public Book Book { get; set; }
		public List<Book> List
		{
			get { return Books; }
		}
		public void OnGet()
        {
        }
		public IActionResult OnPost()
		{

			Books.Add(Book);
			return RedirectToPage("BookAllPages");

		}
	}
}
