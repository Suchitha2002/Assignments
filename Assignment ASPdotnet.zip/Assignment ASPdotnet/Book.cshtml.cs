using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HandsOnModels.Pages
{
    public class BookModel : PageModel
    {
		public class Book
		{
			public int BookId { get; set; }
			public string Name { get; set; }
			public double Price { get; set; }
			public string Language { get; set; }

			public string Author {  get; set; }
		}


		public void OnGet()
        {
        }
    }
}
