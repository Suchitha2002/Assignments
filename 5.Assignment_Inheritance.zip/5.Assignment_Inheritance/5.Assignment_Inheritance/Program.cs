﻿namespace Assignment5Inheritance
{
    public class Furniture
    {
        int orderid;
        string orderdate;
        public static string furnituretype;
        int qty;
        int totalamt;
        string paymentmode;

        public void GetData()
        {
            orderid = int.Parse(Console.ReadLine());
            orderdate = Console.ReadLine();
            furnituretype = Console.ReadLine();
            qty = int.Parse(Console.ReadLine());
            totalamt = int.Parse(Console.ReadLine());
            paymentmode = Console.ReadLine();
        }
        public void ShowData()
        {
            Console.WriteLine($"orderid:{orderid} orderdate:{orderdate} furnituretype:{furnituretype} qty:{qty} totalamt:{totalamt} paymentmode:{paymentmode}");
        }
    }
    public class Chair : Furniture
    {
        string type;
        string purpose;
        public void GetData()
        {
            Console.WriteLine("Enter the type of the chair 1.Wood 2.Steel 3.Plastic");
            type = Console.ReadLine();
            switch (type)
            {
                case "Wood":
                    {
                        string woodtype = Console.ReadLine();
                        Console.WriteLine("Woodtype:" + woodtype);
                        break;
                    }
                case "Steel":
                    {
                        string color = Console.ReadLine();
                        Console.WriteLine("Color:" + color);
                        break;
                    }
                case "Plastic":
                    {
                        string color = Console.ReadLine();
                        Console.WriteLine("Color:" + color);
                        break;
                    }
            }
            purpose = Console.ReadLine();
        }
        public void ShowData()
        {
            Console.WriteLine($"Chair type:{type} Purpose:{purpose}");
        }
    }
    public class Cot : Furniture
    {
        string type;
        string capacity;
        int rate;
        public void GetData()
        {
            Console.WriteLine("Enter the type of the Cot 1.Wood 2.Steel 3.Plastic");
            type = Console.ReadLine();
            switch (type)
            {
                case "Wood":
                    {
                        string woodtype = Console.ReadLine();
                        Console.WriteLine("Woodtype:" + woodtype);
                        break;
                    }
                case "Steel":
                    {
                        string color = Console.ReadLine();
                        Console.WriteLine("Color:" + color);
                        break;
                    }
            }
            capacity = Console.ReadLine();
            rate = int.Parse(Console.ReadLine());
        }
        public void ShowData()
        {
            Console.WriteLine($"Cot type:{type} Capacity:{capacity} rate:{rate}");
        }
        class result
        {
            static void Main(string[] args)
            {
                Furniture ob2 = new Chair();
                ob2.GetData();
                ob2.ShowData();

                if (furnituretype == "Chair")
                {
                    Chair ob = new Chair();
                    ob.GetData();
                    ob.ShowData();
                }
                else
                {
                    Cot ob1 = new Cot();
                    ob1.GetData();
                    ob1.ShowData();
                }
            }
        }
    }
}