using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Assignments.Pages.Pages
{
    public class Index1Model : PageModel
    {
        [BindProperty]
        public string username { get; set; }
        [BindProperty]
        public int password { get; set; }
        public string message;


        public void OnGet()
        {

        }
        public void OnPost()
        {
            if (username == "virat" && password == 12345)
            {
                message = "login Successful!!!";
            }
            else
            {
                message = "login UnSuccessFull!!!";
            }

        }
    }
}