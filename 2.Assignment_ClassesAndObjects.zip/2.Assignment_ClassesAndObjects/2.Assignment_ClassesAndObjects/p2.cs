﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Assignment_ClassesAndObjects
{
    internal class p2
    {
        class Accounts
        {
            long Ano;
            string name;
            string acctype;
            int balance;
            public int credit(int camount)
            {
                balance = balance + camount;
                return balance;
            }
            public int debit(int damount)
            {
                balance = balance - damount;
                return balance;
            }
            static void Main()
            {
                Accounts ob = new Accounts();
                ob.Ano = long.Parse(Console.ReadLine());
                ob.name = Console.ReadLine();
                ob.acctype = Console.ReadLine();
                ob.balance = int.Parse(Console.ReadLine());
                do
                {
                    Console.WriteLine("Enter the type of transaction");
                    Console.WriteLine("1.Deposit\n2.Withdraw");
                    int transtype = int.Parse(Console.ReadLine());
                    switch (transtype)
                    {
                        case 1:
                            {
                                Console.WriteLine("Enter amount to deposit");
                                Console.WriteLine("The avail balance after deposit is " + ob.credit(int.Parse(Console.ReadLine())));
                                break;
                            }
                        case 2:
                            {
                                Console.WriteLine("Enter amount to withdraw");
                                Console.WriteLine("The avail balance after deposit is" + ob.debit(int.Parse(Console.ReadLine())));
                                break;
                            }
                        case 3:
                            {
                                Environment.Exit(0);
                                break;
                            }
                    }

                } while (true);
            }
        }
    }
}
