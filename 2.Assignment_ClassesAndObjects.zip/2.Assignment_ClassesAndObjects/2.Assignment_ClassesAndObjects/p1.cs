﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Assignment_ClassesAndObjects
{
    internal class p1
    {
        static void Main(string[] args)
        {
            double M = 1000.0; // Initial debt amount
            double interestRate = 1.5 / 100; // Monthly interest rate
            Console.Write("Enter the monthly payment: ");
            double N = Convert.ToDouble(Console.ReadLine());

            int month = 1;
            double totalPayments = 0;

            while (M > 0)
            {
                M += M * interestRate; // Apply interest
                M -= N; // Make payment
                totalPayments += N;
                if (M > 0)
                {

                    Console.WriteLine($"Month: {month} balance: {M:F2} total payments: {totalPayments:F2}");
                    month++;
                }
                else
                {
                    break;
                }
            }
        }

    }
}
