﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Assignment_ClassesAndObjects
{
    internal class p3
    {
        int rollno;
        string name;
        String cls;
        int sem;
        string branch;
        int total = 0;
        int[] marks = new int[5] { 67, 90, 87, 84, 89 };
        void Displaydata()
        {
            Console.WriteLine("$id:{rollno} name:{name} class:{cls} sem:{sem} branch:{branch}");

        }

        p3()
        {
            rollno = 1222;
            name = "Manju";
            cls = "BTech";
            sem = 4;
            branch = "IT";

        }
        void Displayreult()
        {
            for(int i=0;i<5;i++)
            {
                total = total + marks[i];
            }
            int avg = total / 5;
            for(int i=0;i<5;i++)
            {
                if (marks[i]>35&&avg>50)
                {
                    Console.WriteLine("Passed");
                    break;
                }
                else
                {
                    Console.WriteLine("Failed");
                }
            }
        }
        static void Main()
        {
            p3 ob = new p3();
            ob.Displaydata();
            ob.Displayreult();

        }

        
    }
}
