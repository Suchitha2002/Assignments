﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Assignment_ClassesAndObjects
{
    internal class Bookdetails
    {
        int isdn;
        string bookname;
        string booktitle;
        string bookauthor;
        const int quaofbooks = 3;
        int bookprice;
        int total = 0;
        void display()
        {
            for (int i = 1; i <= quaofbooks; i++)
            {
                isdn = int.Parse(Console.ReadLine());
                bookname = Console.ReadLine();
                booktitle = Console.ReadLine();
                bookauthor = Console.ReadLine();
                bookprice = int.Parse(Console.ReadLine());
                Console.WriteLine($"isdn:{isdn} bookname:{bookname} booktitle:{booktitle} quantity:{quaofbooks} bookprice:{bookprice}");
                total = total + bookprice;
            }
        }
        void Billamount()
        {
            Console.WriteLine("The Total Billamount = " + total);
        }
        static void Main()
        {
            Bookdetails ob = new Bookdetails();
            ob.display();
            ob.Billamount();
        }
    }
}

    
