﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnGenericCollections
{
    internal class AssignmentLIinklist
    {
        static void Main()
        {
            LinkedList<int> list = new LinkedList<int>();
            list.AddFirst(1);
            list.AddFirst(2);
            list.AddFirst(3);
            list.AddFirst(4);
            list.AddFirst(5);
            foreach (int i in list)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine(list.Count);
            list.Clear();
            foreach (int i in list)
            {
                Console.WriteLine(i);
            }
        }
    }
}