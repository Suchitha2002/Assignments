﻿namespace DivisibleByThreeApp
{
    internal class ProgramBase
    {
    }
}