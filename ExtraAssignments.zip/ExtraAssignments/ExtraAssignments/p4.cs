﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraAssignments
{
    internal class p4
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }

        public p4(int id, string name, double price)
        {
            Id = id;
            Name = name;
            Price = price;
        }
        public void IncreasePrice(double percentage)
        {
            Price *= (1 + percentage / 100);
        }
    }
    class product
    {
        static void Main()
        {
            string filePath = "products.txt";
            try
            {

                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length == 3 && int.TryParse(parts[0], out int id) && double.TryParse(parts[2], NumberStyles.Currency, CultureInfo.InvariantCulture, out double price))
                    {
                        p4 product = new p4(id, parts[1].Trim(), price);
                        product.IncreasePrice(10); // Increase price by 10%

                        Console.WriteLine($"{product.Id}, {product.Name}, {product.Price:F2}");
                    }
                    else
                    {
                        Console.WriteLine($"Invalid line format: {line}");

                    }
                    File.WriteAllLines(filePath, lines);
                    Console.WriteLine("File updated successfully!");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }

}











      
 
