﻿using System;
using System.Collections.Generic;

namespace DivisibleByThreeApp
{
    class p6
    {
        // Delegate to check if a number is divisible by 3
        delegate bool IsDivisibleByThree(int num);

        static void Main()
        {
            List<int> numList = new List<int> { 9, 12, 15, 18, 21, 24 };
            
            // Using the delegate
            IsDivisibleByThree checkDivisibility = IsDivisibleBy3;
            List<int> divisibleNumbers = numList.FindAll(checkDivisibility);

            Console.WriteLine("Numbers divisible by 3 (using delegates):");
            foreach (int num in divisibleNumbers)
            {
                Console.Write(num + " ");
            }
        }

        static bool IsDivisibleBy3(int num)
        {
            return num % 3 == 0;
        }
    }
}
