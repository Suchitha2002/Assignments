﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraAssignments
{
    internal class p2
    {

        static void Main(string[] args)
        {
            Console.Write("Enter a sentence: ");
            string inputSentence = Console.ReadLine();

            string[] words = inputSentence.Split(new char[] { ' ', '.', ',', '!', '?' }, StringSplitOptions.RemoveEmptyEntries);
            Dictionary<string, int> wordFrequencies = new Dictionary<string, int>(StringComparer.CurrentCultureIgnoreCase);

            foreach (string word in words)
            {
                if (wordFrequencies.ContainsKey(word))
                    wordFrequencies[word]++;
                else
                    wordFrequencies[word] = 1;
            }

            foreach (var kvp in wordFrequencies)
            {
                Console.WriteLine($"{kvp.Key} - {kvp.Value}");
            }

        }
    }
}



                