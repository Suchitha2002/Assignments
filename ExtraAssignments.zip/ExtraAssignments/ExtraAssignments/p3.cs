﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraAssignments
{
    internal class p3
    {
        public static int Sum(int num1, int num2)
        {
            return num1 + num2;
        }
        static void Main()
        {
            Console.Write("Enter the first number: ");
            int number1 = int.Parse(Console.ReadLine());

            Console.Write("Enter the second number: ");
            int number2 = int.Parse(Console.ReadLine());

            int result = Sum(number1, number2);

            Console.WriteLine($"The sum of {number1} and {number2} is: {result}");
        }

    }
}




