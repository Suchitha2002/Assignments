﻿using System;
using System.Collections.Generic;

namespace DivisibleByThreeApp
{
    internal class p6
    {
        static void Main()
        {
            List<int> numList = new List<int> { 9, 12, 15, 18, 21, 24 };

            // Using a lambda expression
            List<int> divisibleNumbers = numList.FindAll(x => x % 3 == 0);

            Console.WriteLine("Numbers divisible by 3 (using lambda expression):");
            foreach (int num in divisibleNumbers)
            {
                Console.Write(num + " ");
            }
        }
    }
}
