﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtraAssignments
{
    internal class p1
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the monthly payment: ");
            double monthlyPayment = double.Parse(Console.ReadLine());
            double initialBalance = 1000.0;

            double balance = initialBalance;
            double totalPayments = 0.0;
            int month = 1;


            while (balance > 0)
            {
                balance *= 1.015;
                balance -= monthlyPayment;
                totalPayments += monthlyPayment;

       
                Console.WriteLine($"Month: {month} balance: {balance:F6} total payments: {totalPayments:F6}");
                month++;
            }

            Console.WriteLine("Debt paid off!");

        }

    }
}



