﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace Assignment8IO
{
    class Car
    {
        public string Model;
        public string yearofmaking;
        public void Create(string path)
        {
            File.Create(path);
        }
        public void Read(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                string content = sr.ReadToEnd();
                Console.WriteLine(content);
            }
        }
        public void Write(string path)
        {
            using (StreamWriter sw = new StreamWriter(path, true))
            {

                string content = Model + " " + yearofmaking;
                sw.WriteLine(content);
            }
        }
        static void Main()
        {
            Car car = new Car();
            car.Model = "I10";
            car.yearofmaking = "2021";
            Console.WriteLine("Enter Path");
            string path = Console.ReadLine();
            //car.Create(path);
            car.Write(path);
            car.Read(path);
        }
    }

}