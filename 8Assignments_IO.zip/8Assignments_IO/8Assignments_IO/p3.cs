﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8IO
{
    public class error
    {
        public int a;
        public int b;
        public int result;
        public void Create(string path)
        {
            File.Create(path);
        }
        public void Write(string path)
        {
            using (StreamWriter sw = new StreamWriter(path))
            {
                try
                {
                    a = int.Parse(Console.ReadLine());
                    b = int.Parse(Console.ReadLine());
                    result = a / b;
                }
                catch (Exception e)
                {
                    string content = e.Message;
                    sw.WriteLine(content);
                }
            }
        }
    }
    internal class Program3
    {
        static void Main()
        {
            Console.WriteLine("Enter path");
            string path = Console.ReadLine();
            error ob = new error();
            //ob.Create(path);
            ob.Write(path);
        }
    }
}