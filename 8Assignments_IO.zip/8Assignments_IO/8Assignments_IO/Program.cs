﻿namespace Assignment8
{
    internal class Program
    {
        public static void Write(string path)
        {
            Console.WriteLine("Enter no of users:");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter names of the users:");
            string[] arr = new string[n];
            for (int i = 0; i < n; i++)
            {
                arr[i] = Console.ReadLine();
            }
            string[] content = arr;
            File.WriteAllLines(path, content);
        }
        static void Main(string[] args)
        {
            string path = Console.ReadLine();
            Write(path);
        }
    }

}



