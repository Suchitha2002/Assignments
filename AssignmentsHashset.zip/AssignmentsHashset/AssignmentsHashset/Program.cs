﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Write an application to demonstrate hashset and linkedlist
namespace HandsOnGenericCollections
{
    internal class Assignmenthash
    {
        static void Main()
        {
            HashSet<string> set = new HashSet<string>();
            set.Add("Suchitha");
            set.Add("Pandu");
            set.Add("Thoshitha");
            set.Add("Kusuma");
            set.Add("Apple");
            foreach (var i in set)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            Console.WriteLine(set.First());
            Console.WriteLine(set.Remove("Apple"));
            foreach (var i in set)
            {
                Console.WriteLine(i);
            }
        }
    }
}