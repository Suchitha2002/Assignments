﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p19
    {
        static void Main()
        {
            string s = Console.ReadLine();
            string rev = new string(s.Reverse().ToArray());
            if (s.Equals(rev))
            {
                Console.WriteLine("Palindrome");
            }
            else
            {
                Console.WriteLine("Not a Palindrome");
            }
        }

    }
}
