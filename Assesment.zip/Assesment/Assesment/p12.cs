﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p12
    {
        static void Main()
        {
            Console.WriteLine("The numbers divisible by 7 are:");
            for (int i = 201; i <= 300; i++)
            {
                if (i % 7 == 0)
                {
                    Console.WriteLine(i);
                }
            }
        }

    }
}
