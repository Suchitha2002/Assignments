﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p5
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int c = 0, cn = 0;
            int[] arr = new int[n];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] % 2 == 0)
                {
                    c++;
                }
                else
                {
                    cn++;
                }
            }
            Console.WriteLine("No of even numbers is " + c);
            Console.WriteLine("No of odd numbers is " + cn);
        }

    }
}
