﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p6
    {
        static void Main()
        {
            Console.Write("Enter the temperature in Fahrenheit: ");
            string input = Console.ReadLine();

            // Try to parse the input to a double
            if (double.TryParse(input, out double fahrenheit))
            {
                // Convert Fahrenheit to Celsius
                double celsius = (fahrenheit - 32) * 5 / 9;
                Console.WriteLine($"The temperature in Celsius is: {celsius:F2}");
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a numeric value.");
            }



        }

    }
}
