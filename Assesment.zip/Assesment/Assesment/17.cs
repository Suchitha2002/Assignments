﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class _17
    {
        static void Main()
        {
            string s = Console.ReadLine();
            char[] c = s.ToCharArray();
            for (int i = c.Length - 1; i >= 0; i--)
            {
                Console.Write(c[i]);
            }
        }

    }
}
