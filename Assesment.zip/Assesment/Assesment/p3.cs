﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p3
    {
        static void Main()
        {
            {
                int a = 3;
                int b = 10;
                for (int i = a + 1; i < b; i++)
                {
                    Console.WriteLine(i);

                }
            }
        }
    }
}
