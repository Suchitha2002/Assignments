﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p18
    {
        static void Main()
        {
            string s = Console.ReadLine();
            string s1 = Console.ReadLine();
            s = s.ToLower();
            s1 = s1.ToLower();
            int count = 0;
            if (s.Equals(s1))
            {
                Console.WriteLine("Same");
            }
            else
            {
                Console.WriteLine("not Same");
            }
        }

    }
}
