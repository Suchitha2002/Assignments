﻿namespace Assesment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the world of c#");
        }
    }
}
