﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p14
    {
        static void Main()
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            int d = int.Parse(Console.ReadLine());
            int e = int.Parse(Console.ReadLine());
            if (a < b && a < c && a < d && a < e)
            {
                Console.WriteLine("The smallest number is:" + a);
            }
            else if (b < a && b < c && b < d && b < e)
            {
                Console.WriteLine("The smallest number is:" + b);
            }
            else if (c < a && c < b && c < d && c < e)
            {
                Console.WriteLine("The smallest number is:" + c);
            }
            else if (d < a && d < b && d < c && d < e)
            {
                Console.WriteLine("The smallest number is:" + d);
            }
            else
            {
                Console.WriteLine("The smallest number is:" + e);
            }
        }

    }
}
