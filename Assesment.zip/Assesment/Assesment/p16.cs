﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p16
    {
        static void Main()
        {
            string s = Console.ReadLine();
            Console.WriteLine(s.Length);
        }

    }
}
