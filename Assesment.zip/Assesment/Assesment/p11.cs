﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p11
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Multiplication table of a given number is:");
            for (int i = 1; i <= 20; i++)
            {
                Console.WriteLine($"{n}*{i}={n * i}");
            }
        }

    }
}
