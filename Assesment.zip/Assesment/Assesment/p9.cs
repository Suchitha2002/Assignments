﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p9
    {
        static void Main()
        {
            int n = 40;
            int c;
            int a = 0, b = 1;
            for (int i = 0; i <= n; i++)
            {
                Console.WriteLine(a);
                c = a + b;
                a = b;
                b = c;
                if (a > 40)
                {
                    break;
                }
            }
        }

    }
}
