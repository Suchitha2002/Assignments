﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p10
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            int sum = 0;
            for (int i = 1; i <= N; i++)
            {
                int m = i * i * i;
                Console.WriteLine(m);
                sum = sum + m;
            }
            Console.WriteLine("sum of cubes " + sum);
        }

    }
}
