﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p15a
    {
        static void Main()
        {
            int[] a = new int[10];
            int total = 0;
            for (int i = 0; i < 10; i++)
            {
                a[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < 10; i++)
            {
                total = total + a[i];
            }
            Console.WriteLine(total);
            int avg = total / 10;
            Console.WriteLine(avg);
            Console.WriteLine(a.Max());
            Console.WriteLine(a.Min());
        }

    }

}

