﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment
{
    internal class p2
    {
        static void Main()
        {
            String name = "Suchi";
            Console.WriteLine("Hi! " + name + " \nWelcome to the world of C#");

        }
    }
}
